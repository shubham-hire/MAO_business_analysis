---
name: Technical Editorial
colors:
  surface: '#f9f9f8'
  surface-dim: '#dadad9'
  surface-bright: '#f9f9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f3'
  surface-container: '#eeeeed'
  surface-container-high: '#e8e8e7'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#444748'
  inverse-surface: '#2f3130'
  inverse-on-surface: '#f1f1f0'
  outline: '#747878'
  outline-variant: '#c4c7c7'
  surface-tint: '#5f5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1c1b1b'
  on-primary-container: '#858383'
  inverse-primary: '#c8c6c5'
  secondary: '#545f6c'
  on-secondary: '#ffffff'
  secondary-container: '#d8e3f3'
  on-secondary-container: '#5a6572'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#1d1b1a'
  on-tertiary-container: '#868381'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c8c6c5'
  on-primary-fixed: '#1c1b1b'
  on-primary-fixed-variant: '#474646'
  secondary-fixed: '#d8e3f3'
  secondary-fixed-dim: '#bcc8d6'
  on-secondary-fixed: '#121c27'
  on-secondary-fixed-variant: '#3d4854'
  tertiary-fixed: '#e6e1df'
  tertiary-fixed-dim: '#cac6c3'
  on-tertiary-fixed: '#1d1b1a'
  on-tertiary-fixed-variant: '#484645'
  background: '#f9f9f8'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
  canvas-base: '#FCFCFB'
  surface-subtle: '#F2F2F0'
  border-hairline: '#E3E3DE'
  border-strong: '#111111'
  text-muted: '#6E7175'
  slate-accent: '#384551'
  accent-focus: '#202830'
typography:
  display:
    fontFamily: Hanken Grotesk
    fontSize: 3.5rem
    fontWeight: '600'
    lineHeight: '1.1'
    letterSpacing: -0.03em
  display-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 2.25rem
    fontWeight: '600'
    lineHeight: '1.15'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 2.25rem
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 1.75rem
    fontWeight: '600'
    lineHeight: '1.25'
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 1.5rem
    fontWeight: '500'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Hanken Grotesk
    fontSize: 1.125rem
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: -0.005em
  body-lg:
    fontFamily: DM Sans
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: '0'
  body-md:
    fontFamily: DM Sans
    fontSize: 0.9375rem
    fontWeight: '400'
    lineHeight: '1.55'
    letterSpacing: '0'
  body-sm:
    fontFamily: DM Sans
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: 0.01em
  label-technical:
    fontFamily: JetBrains Mono
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: 0.04em
  label-code:
    fontFamily: JetBrains Mono
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: '1.4'
    letterSpacing: '0'
  label-metric:
    fontFamily: JetBrains Mono
    fontSize: 1.5rem
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: -0.02em
spacing:
  gutter: 1.5rem
  gutter-desktop: 2rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system embodies high-craft technical editorialism, tailored for rigorous, evidence-based market research and analysis. It blends the structural clarity of modernist typography with the exacting precision of analytical instruments.

### Key Tenets
- **Quiet Confidence**: Avoid theatrical flourishes, gradients, or marketing hyperbole. Authority is earned through immaculate typographic balance, deliberate negative space, and unambiguous data hierarchy.
- **Architectural Structure**: Surfaces are defined through structural hairline grid lines and spatial separation rather than decorative shadows or faux-depth.
- **Rigorous Documentation**: Every metric, citation, and analytical claim is presented with forensic legibility, bridging institutional editorial authority and modern investigative technology.

## Colors

The palette is an uncompromising, high-contrast monochrome ecosystem anchored by deep graphite charcoal (`#111111`) and an architectural warm off-white canvas (`#FCFCFB`). 

### Usage Guidelines
- **Primary (`#111111`)**: Primary typography, heavy structural delimiters, high-emphasis interactive states, and active chart baselines.
- **Secondary (`#5A6572`)**: Neutral technical accents, secondary data dimensions, supporting labels, and inactive tab chrome.
- **Neutral (`#F8F8F7`)**: Secondary analytical cards, data grid alternating bands, and subtle elevated panes.
- **Hairline Delimiters (`#E3E3DE`)**: Used universally for 1px layout boundaries, table borders, and structural modular separators.
- Avoid non-neutral saturated hues except for status-critical validation tags (which must remain muted and subdued).

## Typography

The typographic hierarchy couples **Hanken Grotesk** for structural, authoritative editorial headings, **DM Sans** for neutral and highly legible narrative analysis, and **JetBrains Mono** for metric readouts, citations, system statuses, and tabular data.

### Typographic Rules
- All research parameters, timestamps, reference IDs, and scalar quantitative metrics must be rendered using `JetBrains Mono`.
- Headings maintain tight letter-spacing to reinforce architectural solidity.
- Maintain strict baseline alignment across multi-column data views.

## Layout & Spacing

The layout is grounded in a modular 12-column analytical grid flanked by generous margins that give research reports room to breathe.

### Responsive Structure
- **Desktop (1200px+)**: 12-column grid with `2rem` gutters and minimum `3rem` outer margins. Content panels adhere strictly to explicit column spans (3, 6, 8, 12).
- **Tablet (768px - 1199px)**: 8-column grid with `1.5rem` gutters and `2rem` margins. Side panels dock to lower draw layers.
- **Mobile (< 768px)**: 4-column fluid layout with `1rem` margins and full-width modular stacks.

### Structural Lines
Where modules sit adjacent to one another, use continuous `1px solid var(--border-hairline)` bounding lines instead of card margins to evoke the precision of a printed technical prospectus.

## Elevation & Depth

This system intentionally eliminates traditional ambient drop shadows, blurs, and skeuomorphic depth in favor of **low-contrast outlines** and **tonal surface layering**.

### Depth Hierarchy
- **Canvas Base (`#FCFCFB`)**: The default root plane.
- **Surface Level 1 (`#F8F8F7`)**: Secondary analytical modules, inspection toolbars, and metadata drawers. Separated from base by hairline borders (`#E3E3DE`).
- **Overlays & Drawers**: Pure `#FFFFFF` backdrops isolated by a 1px solid border in `#111111` or `#E3E3DE`. No drop shadows; spatial depth is signaled solely by crisp border hierarchy and explicit dark backdrop scrims (`rgba(17, 17, 17, 0.4)`).

## Shapes

To mirror the unyielding rigor of quantitative research and tabular documentation, the shape language is strictly **sharp (`0px` / zero radius)** across all core UI elements, controls, tables, and containers.

### Shape Execution
- Buttons, inputs, chips, modal sheets, and notification banners terminate in precise 90-degree right angles.
- Sub-components such as inner tags or indicator badges retain the same sharp corner treatment.
- Visual variety must be generated through layout proportions, border line-weights (hairline `1px` vs accent `2px`), and typographic scaling rather than corner radiuses.

## Components

### Buttons
- **Primary**: Solid `#111111` fill, crisp `#FFFFFF` text, 0px border radius, uppercase or title-case `DM Sans` medium. Padding: `0.625rem 1.25rem`.
- **Secondary / Outline**: `#FCFCFB` surface, `1px solid #111111` border, `#111111` label. Hover activates `#111111` fill with inverted text.
- **Technical Action**: Monospaced font (`JetBrains Mono`), `1px solid #E3E3DE` border, `space-xs` horizontal gap with a trailing action symbol (e.g., `[ENTER]`, `->`).

### Input Fields & Search
- Background: `#FCFCFB`.
- Border: `1px solid #E3E3DE`. Focus state transitions to `1px solid #111111` without glow effects.
- Typography: Inputs use `DM Sans` (14px/15px), placeholder text uses `JetBrains Mono` at `text-muted`.
- Inline query bars incorporate a fixed monospaced label prefix (e.g., `QUERY //`).

### Chips & Metadata Badges
- Sharp rectangles with `1px solid #E3E3DE` borders.
- Padding: `0.125rem 0.5rem`.
- Typography: `JetBrains Mono` label at `0.75rem`.
- Inactive tags use subtle background `#F2F2F0`; active filter tags invert to `#111111` background with white text.

### Data Tables & Lists
- Table headers: Uppercase `JetBrains Mono`, tracking `0.05em`, border bottom `1px solid #111111`.
- Rows: Hairline bottom borders (`#E3E3DE`). Height: `44px` minimum. Numeric data right-aligned in monospace.
- Hover state: Subtle background fill change to `#F2F2F0` without row expansion.

### Checkboxes & Radio Buttons
- Square geometry (`16x16px`) with `1px solid #111111` borders.
- Checked state: Solid `#111111` square inset by 3px of canvas space. Radio buttons are square frames containing an inner square dot to preserve the uncompromising geometry.

### Analytical Cards & Dossiers
- Framed with continuous `1px solid #E3E3DE` lines.
- Card header zones are separated from card bodies by an internal horizontal hairline border.
- Cards contain header metadata slots (e.g., `SEC-01`, `CONFIDENCE: 98.4%`) positioned in the upper right in `JetBrains Mono`.